#pragma once
#include "Controller.h"

class Tests
{
public:
	Tests();
	static void testDynamicArray();
	static void testController();
	static void testDog();
	static void testRepo();
	void runAll();
	~Tests();
};

