#include "Validator.h"
#include "Dog.h"
#include <string>


Validator::Validator()
{
}


Validator::~Validator()
{
}

bool Validator::validateDog(T e)
{
	if (validateAge(e.getAge()) && validateName(e.getName()) && validatePic(e.getPic()))
		return true;
	return false;
}

bool Validator::validateName(string name)
{
	if (name == "")
		return false;
	return true;
}

bool Validator::validateAge(int age)
{
	if (age < 0 || age > 20)
		return false;
	return true;
}

bool Validator::validatePic(string pic)
{
	if (pic == "")
		return false;
	return true;
}



