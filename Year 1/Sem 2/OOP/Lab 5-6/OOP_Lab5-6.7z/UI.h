#pragma once
#include "Controller.h"

class UI
{
	public:
		UI();
		~UI();
		void admMenu();
		void userMenu();
		void run();
		void smth(DynamicArray<Dog> da);

	private:
		Controller ctrl;
};

