#pragma once

#include "DynamicArray.h"
#include <string>

using namespace std;

class FileManager
{
public:
	static void loadFromFile(DynamicArray<Dog> &da);
	static void writeToFile(DynamicArray<Dog> &da);
};

