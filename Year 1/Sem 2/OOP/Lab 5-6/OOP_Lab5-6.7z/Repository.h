#pragma once
#include "DynamicArray.h"

typedef Dog TElem;

class Repository
{
	public:
		Repository();
		~Repository();
		void add(TElem e);
		void remove(string name);
		void update(string name, string newName, string breed, int age, string pic);
		int search(string e);
		int size();
		DynamicArray<TElem> getDogs();
		//DynamicArray getAdoptions();

	private:
		DynamicArray<TElem> da;
};


