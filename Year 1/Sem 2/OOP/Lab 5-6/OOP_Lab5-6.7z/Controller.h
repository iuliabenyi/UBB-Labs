#pragma once
#include "Validator.h"
#include "Repository.h"
#include <string>

class Controller
{
	public:
		Controller();
		~Controller();

		bool add(T e);
		bool addAdoption(T e);
		bool remove(string name);
		bool update(string name, string newName, string breed, int age, string pic);
		bool nameExists(string name);
		DynamicArray<Dog> getFilteredDogs(string breed, int age);
		DynamicArray<Dog> getDogs();
		DynamicArray<Dog> getAdoptions();

	private:
		Repository repo;
		DynamicArray<Dog> adoption;
};

