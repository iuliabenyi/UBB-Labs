// OOP_Lab5-6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "UI.h"
#include "DynamicArray.h"
#include <iostream>
#include <crtdbg.h>
using namespace std;

int main()
{
	
	/*
	DynamicArray<Dog> da;
	Dog d1 = Dog("BREED", "NAME", 6, "PIC");
	Dog d2 = Dog("BREEDD", "NAMEE", 9, "PICC");


	da = da + d1;
	cout << "Size1: " << da.getSize() << endl;

	da = d2 + da;
	cout << "Size2: " << da.getSize() << endl << endl;*/
	
	UI ui = UI();
	ui.run();
	_CrtDumpMemoryLeaks();


	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
