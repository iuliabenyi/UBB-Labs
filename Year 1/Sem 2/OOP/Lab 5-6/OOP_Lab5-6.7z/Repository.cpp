#include "Repository.h"
#include "FileManager.h"



Repository::Repository()
{
	this->da = DynamicArray<Dog>(20);
	FileManager::loadFromFile(da);
}

Repository::~Repository()
{
}

void Repository::add(TElem e)
{
	da.add(e);
	FileManager::writeToFile(da);
}

void Repository::remove(string name)
{
	da.deleteElement(da.searchElement(name));
	FileManager::writeToFile(da);
}

void Repository::update(string name, string newName, string breed, int age, string pic)
{
	da.updateElement(da.searchElement(name), breed, newName, age, pic);
	FileManager::writeToFile(da);
}

int Repository::search(string e)
{
	return da.searchElement(e);
}

int Repository::size()
{
	return da.getSize();
}

DynamicArray<Dog> Repository::getDogs()
{
	return da;
}

//DynamicArray Repository::getAdoptions()
//{
//	return adoption;
//}