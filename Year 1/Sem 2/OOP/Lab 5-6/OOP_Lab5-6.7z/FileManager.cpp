#include "FileManager.h"

void FileManager::loadFromFile(DynamicArray<Dog> & da)
{
	ifstream in("file.txt");
	Dog dog;
	while (in >> dog)
	{
		da.add(dog);
	}
}

void FileManager::writeToFile(DynamicArray<Dog> & da)
{
	ofstream out("file.txt");
	for (int i = 0; i < da.getSize(); ++i)
	{
		out << da[i].getName() + "," << da[i].getAge() << "," + da[i].getBreed() << "," + da[i].getPic() << endl;
	}
}
