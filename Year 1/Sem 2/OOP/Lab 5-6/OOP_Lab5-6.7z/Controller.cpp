#include "Controller.h"
#include "Repository.h"



Controller::Controller()
{
	this->repo = Repository();
	this->adoption = DynamicArray<Dog>(repo.size());
}


Controller::~Controller()
{
}

bool Controller::add(T e)
{
	if (Validator::validateDog(e) && !nameExists(e.getName()))
	{
		repo.add(e);
		delete& this->repo;
		return true;
	}
	return false;
}

bool Controller::addAdoption(T e)
{
	if (Validator::validateDog(e) /*&& !nameExists(e.getName())*/)
	{
		adoption.add(e);
		return true;
	}
	return false;
}

bool Controller::remove(string name)
{	
	if (Validator::validateName(name) && repo.search(name) != -1)
	{
		repo.remove(name);
		return true;
	}
	return false;
}

bool Controller::update(string name, string newName, string breed, int age, string pic)
{
	if (Validator::validateDog(Dog(breed, name, age, pic)) && repo.search(name) != -1)
	{
		repo.update(name, newName, breed, age, pic);
		return true;
	}
	return false;
}

bool Controller::nameExists(string name)
{
	return repo.search(name) != -1;
}

DynamicArray<Dog> Controller::getFilteredDogs(string breed, int age)
{
	DynamicArray<Dog> da = DynamicArray<Dog>(repo.size());
	for (int i = 0; i < getDogs().getSize(); i++)
	{
		auto dog = getDogs()[i];
		if (dog.getBreed() == breed && dog.getAge() < age)
			da.add(dog);
	}
	return da;
}

DynamicArray<Dog> Controller::getDogs()
{
	return repo.getDogs();
}

DynamicArray<Dog> Controller::getAdoptions()
{
	return adoption;
}

