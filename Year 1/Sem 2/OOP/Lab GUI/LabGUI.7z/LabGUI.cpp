#include "LabGUI.h"

LabGUI::LabGUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
